const db = new PouchDB('envios');
function guardarEnvio(envio) {
    envio._id = new Date().toISOString();
    return db.put(envio).then(() => {
        self.registration.sync.register('nuevo-envio');
        const newResp = {
            ok: true,
            offline: true
        };
       return new Response(JSON.stringify(newResp))
    })
}

function postEnvios() {
    const envios = [];
    return db.allDocs({include_docs: true}).then(docs => {
       docs.rows.forEach(row => {
          const doc = row.doc;
           const fetchProm = fetch('api', {
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json'
               },
               body: JSON.stringify(doc)
           })
               .then(res => {
                  return db.remove(doc);
               });
           envios.push(fetchProm);
       });
       return Promise.all(envios)

    });
}