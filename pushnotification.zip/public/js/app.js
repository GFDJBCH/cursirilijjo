// Registrar SW.
var url = window.location.href;
var swLocation = '/seguimiento/sw.js';
var swReg;
if (navigator.serviceWorker) {
    if ( url.includes('localhost') ) {
        swLocation = '/sw.js';
    }


    window.addEventListener('load', function () {
        navigator.serviceWorker.register( swLocation ).then(function (reg) {
           swReg = reg;
           swReg.pushManager.getSubscription().then(verificaSuscripcion)
        });
    })


}


// Recupera el formulario y el contenedor de envíos
const btnNotificaiconDesactivada = $("#btnNotificaiconDesactivada");
const btnNotificaiconActivada = $("#btnNotificaiconActivada");
const formulario = document.getElementById("formulario-envio");
const modal = new bootstrap.Modal(document.querySelector("#modal-envio"))

const enviosContainer = document.querySelector("#envios");

// Añade un evento al enviar el formulario
formulario.addEventListener("submit", function(event) {
    // Previene el envío por defecto del formulario
    event.preventDefault();

    // Recupera los valores del formulario
    const nombre = formulario.querySelector("#nombre").value;
    const numero = formulario.querySelector("#numero").value;


    let envio = {
        nombre: nombre,
        numero: numero
    }

    fetch('api', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(envio)
    })
        .then(res => res.json())
        .then(res => console.log("submit", res))
        .catch(err => console.log("submit error", err));


    // Enviar información de envio a funcion para crear elemento.
    crearEnvioHtml(nombre, numero);

/*    // Pide permiso para enviar notificaciones push
    Notification.requestPermission().then(function(permission) {
        if (permission === "granted") {
            // Si el usuario acepta, crea una notificación
            const notification = new Notification("Nuevo envío agregado", {
                body: `El envío con nombre "${nombre}" ha sido agregado con éxito.`,
            });
        }
    });*/

    // Limpia el formulario
    formulario.reset();
    modal.hide();
});


function crearEnvioHtml(nombre, numero) {

    // Agrega el envío a la lista de envíos
    const envio = document.createElement("div");
    envio.classList.add('bg-custom');
    envio.innerHTML = `<h2>${nombre}</h2><p class="m-0">Número de seguimiento: ${numero}</p>`;
    enviosContainer.appendChild(envio);
}



function getEnvios() {
    fetch('api').then(res => res.json()).then(posts => {
        console.log(posts);
        posts.forEach(post => crearEnvioHtml(post.nombre, post.numero));
    })
}
getEnvios();

// Detectar cambios de conexion
function isOnline() {
    if (navigator.onLine) {
    //     Hay conexión
        $.mdtoast('Online', {
            interaction: true,
            interactionTimeout: 1000,
            actionText: 'OK!'
        })
    } else {
        $.mdtoast('Offline', {
            interaction: true,
            actionText: 'OK!',
            type: 'warning'
        })
    }
}

window.addEventListener('online', isOnline);
window.addEventListener('offline', isOnline);
isOnline();

//nota NPush


// Notificaciones
function enviarNotificacion() {

    const notificationOpts = {
        body: 'Este es el cuerpo de la notificación',
        icon: 'img/icons/icon-72x72.png'
    };


    const n = new Notification('Hola Mundo', notificationOpts);

    n.onclick = () => {
        console.log('Click');
    };

}
function notificarme() {

    if ( !window.Notification ) {
        console.log('Este navegador no soporta notificaciones');
        return;
    }

    if ( Notification.permission === 'granted' ) {

        // new Notification('Hola Mundo! - granted');
        enviarNotificacion();

    } else if ( Notification.permission !== 'denied' || Notification.permission === 'default' )  {

        Notification.requestPermission( function( permission ) {

            console.log( permission );

            if ( permission === 'granted' ) {
                // new Notification('Hola Mundo! - pregunta');
                enviarNotificacion();
            }

        });

    }

}

// notificarme();

function verificaSuscripcion( activadas ) {

    if ( activadas ) {
        btnNotificaiconActivada.css('display', 'inline');
        btnNotificaiconDesactivada.css('display', 'none');

    } else {
        btnNotificaiconActivada.css('display', 'none');
        btnNotificaiconDesactivada.css('display', 'inline');
    }

}

//Get key
function getPublicKey() {
    // fetch('api/key').then(resp => resp.text()).then(console.log)
    return fetch('api/key').then(resp => resp.arrayBuffer()).then(key => new Uint8Array(key))
//     retornar arreglo pero como Uint8Array

}
// getPublicKey().then(console.log);

btnNotificaiconDesactivada.on('click', function () {
    if ( !swReg ) return console.log('No hay registro de SW');
    getPublicKey().then( function( key ) {
        swReg.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: key
        })
            .then( res => res.toJSON() )
            .then( suscripcion => {
                // console.log(suscripcion);
                fetch('api/subscribe', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify( suscripcion )
                })
                    .then( verificaSuscripcion )
                    .catch( cancelarSuscripcion );
            });
    });
})

function cancelarSuscripcion() {
    swReg.pushManager.getSubscription().then( subs => {
        subs.unsubscribe().then( () =>  verificaSuscripcion(false) );
    });
}

btnNotificaiconActivada.on( 'click', function() {
    cancelarSuscripcion();
});