importScripts('https://cdn.jsdelivr.net/npm/pouchdb@8.0.0/dist/pouchdb.min.js');
importScripts('js/sw-db.js');
importScripts('js/sw-utils.js');

const STATIC_CACHE = 'static-v2';
const DYNAMIC_CACHE = 'dynamic-v1';
const INMUTABLE_CACHE = 'inmutable-v1';

const APP_SHELL = [
    '/',
    'index.html',
    'css/style.css',
    'img/logo/logo.png',
    'js/app.js',
    'js/libs/plugin/mdtoast.min.css',
    'js/libs/plugin/mdtoast.min.js',
];

const APP_SHELL_INMUTABLE = [
    'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css',
    'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js',
    'https://cdn.jsdelivr.net/npm/pouchdb@8.0.0/dist/pouchdb.min.js',
    'js/jquery.js',
];

self.addEventListener('install', e => {
    const cacheStatic = caches.open(STATIC_CACHE).then(cache => cache.addAll(APP_SHELL));
    const cacheInmutable = caches.open(INMUTABLE_CACHE).then(cache => cache.addAll(APP_SHELL_INMUTABLE));
    e.waitUntil(Promise.all([cacheStatic, cacheInmutable]));
});

self.addEventListener('activate', e => {
    const respuesta = caches.keys().then(keys => {
        keys.forEach(key => {
            if (key !== STATIC_CACHE && key.includes('static')) {
                return caches.delete(key);
            }
        });
    });
    e.waitUntil(respuesta);
});

//Network with cache fallback
self.addEventListener( 'fetch', e => {
    let respuesta;
    if (e.request.url.includes('/api')) {
        respuesta = manejoApiEnvios( DYNAMIC_CACHE, e.request );
    } else {
        respuesta = caches.match( e.request ).then( res => {
            if ( res ) {
                actualizarCacheStatico( STATIC_CACHE, e.request, APP_SHELL_INMUTABLE );
                return res;
            } else {
                return fetch( e.request ).then( newRes => {
                    return actualizarCacheDinamico( DYNAMIC_CACHE, e.request, newRes );
                });
            }
        });
    }


    e.respondWith( respuesta );
});

//Sync
self.addEventListener( 'sync', e => {
    console.log("SW sync.")
    if(e.tag === 'nuevo-envio') {
    //     post a DB cuando hay conexion
        const envios = postEnvios();
        e.waitUntil(envios);
    }
});


// Escuchar PUSH
self.addEventListener('push', e => {

    // console.log(e);

    const data = JSON.parse( e.data.text() );

    // console.log(data);


    const title = data.titulo;
    const options = {
        body: data.cuerpo,
        // icon: 'img/icons/icon-72x72.png',
        icon: `img/logo/logo.png`,
        badge: 'img/favicon.ico',
        image: 'https://www.jannalogistic.com.mx/media/main-slider/3.jpg',
        vibrate: [125,75,125,275,200,275,125,75,125,275,200,600,200,600],
        openUrl: '/',
        data: {
            // url: 'https://google.com',
            url: '/',
            id: data.fecha
        },
        actions: [
            {
                action: 'entendido-action',
                title: 'Ok',
                icon: 'img/general/check-mark.png'
            }
        ]
    };


    e.waitUntil( self.registration.showNotification( title, options) );


});


// Cierra la notificacion
self.addEventListener('notificationclose', e => {
    console.log('Notificación cerrada', e);
});


self.addEventListener('notificationclick', e => {


    const notificacion = e.notification;
    const accion = e.action;


    console.log({ notificacion, accion });
    // console.log(notificacion);
    // console.log(accion);


    const respuesta = clients.matchAll()
        .then( clientes => {

            let cliente = clientes.find( c => {
                return c.visibilityState === 'visible';
            });

            if ( cliente !== undefined ) {
                cliente.navigate( notificacion.data.url );
                cliente.focus();
            } else {
                clients.openWindow( notificacion.data.url );
            }

            return notificacion.close();

        });

    e.waitUntil( respuesta );


});