// Routes.js - Módulo de rutas
const express = require('express');
const router = express.Router();
const push = require('./push');

const envios = [];




// Get envios
router.get('/', function (req, res) {
  // res.json('Obteniendo envios');
  res.json(envios)
});
// Post envio
router.post('/', function (req, res) {
  const envio = {
    nombre: req.body.nombre,
    numero: req.body.numero
  }
  envios.push(envio);
  res.json({
    ok: true,
    envio
  })
});


// nota: NPush
// npm i web-push
// npm i urlsafe-base64
// Almacenar la sub
router.post('/subscribe', (req, res) => {
  const suscripcion = req.body;
  console.log(suscripcion);
  push.addSubscription(suscripcion);
  res.json('subscribe')
})
// Almacenar la sub
router.get('/key', (req, res) => {
  const key = push.getKey()
  res.send(key)
})
// Enviar notificacion PUSH
// Se controla del lado del SERVER ("privado solo corre backend")
router.post('/push', (req, res) => {
  // res.json('push enviado')

  const post = {
    titulo: req.body.titulo,
    cuerpo: req.body.cuerpo,
    usuario: req.body.fecha
  };


  push.sendPush( post );

  res.json( post );
})


module.exports = router;